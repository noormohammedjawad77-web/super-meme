package dev.crashguard;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Pulls verified/working "crash" exploits from the DupeDB API, finds the ones that touch
 * plugins/version on this server, and posts each NEW one to a Discord webhook as an embed.
 * Nothing is printed to the console except real errors.
 */
final class DupeDbSync {

    record Entry(String id, String name, String status, String plugin, String reason) {}

    private final CrashGuard plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final Set<String> sent = ConcurrentHashMap.newKeySet();
    private final File sentFile;
    private volatile List<Entry> matches = List.of();
    private volatile String status = "never synced";

    DupeDbSync(CrashGuard plugin) {
        this.plugin = plugin;
        this.sentFile = new File(plugin.getDataFolder(), "sent.txt");
        try {
            if (sentFile.exists()) sent.addAll(Files.readAllLines(sentFile.toPath(), StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    List<Entry> matches() { return matches; }
    String status() { return status; }

    void run(boolean manual) {
        String token = plugin.getConfig().getString("dupedb.token", "");
        String webhook = plugin.getConfig().getString("dupedb.webhook-url", "");
        if (token.isBlank() || token.equals("PUT_YOUR_PAT_HERE")) { status = "no token set (dupedb.token)"; return; }
        if (webhook.isBlank() || webhook.equals("PUT_WEBHOOK_URL_HERE")) { status = "no webhook set (dupedb.webhook-url)"; return; }

        String base = plugin.getConfig().getString("dupedb.base-url", "https://dupedb.net/api");
        int maxPages = Math.max(1, plugin.getConfig().getInt("dupedb.max-pages", 4));
        int maxSend = Math.max(1, plugin.getConfig().getInt("dupedb.max-per-sync", 15));

        Map<String, String> installed = new LinkedHashMap<>();
        for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
            String n = p.getName();
            if (n.length() >= 4 && !n.equalsIgnoreCase("crashguard")) installed.put(n.toLowerCase(Locale.ROOT), n);
        }
        String mcVersion = Bukkit.getMinecraftVersion();

        List<Entry> found = new ArrayList<>();
        try {
            for (int page = 1; page <= maxPages; page++) {
                HttpResponse<String> res = get(base + "/exploits/search?type=crash&status=verified,working&limit=50"
                        + "&sort=date_submitted&order=desc&page=" + page, token);
                if (!ok(res)) return;
                JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
                JsonArray arr = root.getAsJsonArray("exploits");
                if (arr != null) {
                    for (JsonElement el : arr) {
                        JsonObject ex = el.getAsJsonObject();
                        String[] m = match(ex, installed, mcVersion);
                        if (m != null) found.add(new Entry(str(ex, "id"), str(ex, "name"), str(ex, "status"), m[0], m[1]));
                    }
                }
                boolean more = root.has("pagination") && root.getAsJsonObject("pagination").has("hasMore")
                        && root.getAsJsonObject("pagination").get("hasMore").getAsBoolean();
                if (!more) break;
                Thread.sleep(2500);
            }
            matches = List.copyOf(found);

            int posted = 0;
            for (Entry e : found) {
                if (sent.contains(e.id())) continue;
                if (posted >= maxSend) break;
                String how = fetchDescription(base, token, e.id());
                if (!post(webhook, embed(e, how))) break;
                markSent(e.id());
                posted++;
                Thread.sleep(2500);
            }
            status = "synced: " + found.size() + " relevant, " + posted + " sent to Discord";
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        } catch (Exception ex) {
            status = "error: " + ex.getClass().getSimpleName();
            plugin.getLogger().warning("DupeDB sync failed: " + ex.getMessage());
        }
    }

    /** Sends a sample embed so you can check the webhook/format. */
    boolean sendTest() {
        String webhook = plugin.getConfig().getString("dupedb.webhook-url", "");
        if (webhook.isBlank() || webhook.equals("PUT_WEBHOOK_URL_HERE")) return false;
        try {
            return post(webhook, embed(new Entry("TEST", "Test exploit", "verified", "ExamplePlugin", "plugin"),
                    "هذا اختبار للإيمبد، ما فيه ثغرة حقيقية."));
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------- helpers ----------------

    private HttpResponse<String> get(String url, String token) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Accept", "application/json")
                .timeout(Duration.ofSeconds(15)).GET().build();
        return http.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private boolean ok(HttpResponse<String> res) {
        int c = res.statusCode();
        if (c == 200) return true;
        status = switch (c) {
            case 401 -> "token invalid/revoked (401)";
            case 429 -> "DupeDB rate limited (429), will retry later";
            default -> "DupeDB HTTP " + c;
        };
        return false;
    }

    private String fetchDescription(String base, String token, String id) {
        try {
            HttpResponse<String> res = get(base + "/exploits/" + id, token);
            if (res.statusCode() == 200) {
                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                String d = str(o, "description").trim();
                if (!d.isEmpty()) return d;
            }
        } catch (Exception ignored) {}
        return "غير متوفر، شوفها في DupeDB برقم: " + id;
    }

    private JsonObject embed(Entry e, String how) {
        String title = plugin.getConfig().getString("dupedb.embed-title", "STARK NETWORK");
        JsonArray fields = new JsonArray();
        fields.add(field("البلوقن", e.plugin().equals("-") ? "غير محدد (مطابقة إصدار " + Bukkit.getMinecraftVersion() + ")" : e.plugin(), true));
        fields.add(field("الثغرة", e.name(), true));
        fields.add(field("طريقة تنفيذها", how, false));

        JsonObject footer = new JsonObject();
        footer.addProperty("text", "DupeDB • " + e.id());

        JsonObject emb = new JsonObject();
        emb.addProperty("title", title);
        emb.addProperty("color", 0xE74C3C);
        emb.add("fields", fields);
        emb.add("footer", footer);
        emb.addProperty("timestamp", Instant.now().toString());

        JsonArray embeds = new JsonArray();
        embeds.add(emb);
        JsonObject payload = new JsonObject();
        payload.add("embeds", embeds);
        return payload;
    }

    private static JsonObject field(String name, String value, boolean inline) {
        if (value == null || value.isBlank()) value = "-";
        if (value.length() > 1000) value = value.substring(0, 997) + "...";
        JsonObject f = new JsonObject();
        f.addProperty("name", name);
        f.addProperty("value", value);
        f.addProperty("inline", inline);
        return f;
    }

    private boolean post(String url, JsonObject payload) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("Content-Type", "application/json")
                .timeout(Duration.ofSeconds(15))
                .POST(HttpRequest.BodyPublishers.ofString(payload.toString(), StandardCharsets.UTF_8)).build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        int c = res.statusCode();
        if (c >= 200 && c < 300) return true;
        status = c == 429 ? "webhook rate limited, will retry later" : "webhook HTTP " + c;
        return false;
    }

    private void markSent(String id) {
        sent.add(id);
        try {
            plugin.getDataFolder().mkdirs();
            Files.writeString(sentFile.toPath(), id + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {}
    }

    private String[] match(JsonObject ex, Map<String, String> installed, String mcVersion) {
        StringBuilder hay = new StringBuilder();
        hay.append(str(ex, "plugin_name")).append(' ');
        if (ex.has("plugins") && !ex.get("plugins").isJsonNull()) hay.append(ex.get("plugins"));
        String text = hay.toString().toLowerCase(Locale.ROOT);
        for (Map.Entry<String, String> p : installed.entrySet()) {
            if (text.contains(p.getKey())) return new String[]{p.getValue(), "plugin"};
        }
        if (ex.has("minecraft_versions") && ex.get("minecraft_versions").isJsonArray()) {
            for (JsonElement v : ex.getAsJsonArray("minecraft_versions")) {
                if (v.getAsString().equals(mcVersion)) return new String[]{"-", "version"};
            }
        }
        return null;
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }
}
