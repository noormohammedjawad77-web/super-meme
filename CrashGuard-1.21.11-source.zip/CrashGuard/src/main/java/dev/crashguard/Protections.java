package dev.crashguard;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.FireworkMeta;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/** Generic anti-crash / anti-lag guards. All limits come from config.yml. */
final class Protections implements Listener {

    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();

    private final CrashGuard plugin;
    private final Rate rate = new Rate();
    private final AtomicLong blocked = new AtomicLong();
    private volatile long lastLog = 0;

    Protections(CrashGuard plugin) {
        this.plugin = plugin;
    }

    Rate rate() { return rate; }
    long blocked() { return blocked.get(); }

    private FileConfiguration cfg() { return plugin.getConfig(); }

    private boolean bypass(Player p) { return p.hasPermission("crashguard.bypass"); }

    private void hit(String what, String who) {
        blocked.incrementAndGet();
        long now = System.currentTimeMillis();
        if (now - lastLog > 5000) { // لا تغرق الكونسول
            lastLog = now;
            plugin.getLogger().warning("Blocked [" + what + "] from " + who);
        }
    }

    private static String chunkKey(Location l) {
        return l.getWorld().getName() + ":" + (l.getBlockX() >> 4) + ":" + (l.getBlockZ() >> 4);
    }

    // ---------- Join flood ----------
    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        String ip = e.getAddress().getHostAddress();
        int max = cfg().getInt("protection.join.max-per-ip", 3);
        long win = cfg().getLong("protection.join.window-seconds", 10) * 1000L;
        if (rate.exceeded("join:" + ip, max, win)) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, Component.text("Too many connections, wait a bit."));
            hit("join-flood", ip);
        }
    }

    // ---------- Chat / commands ----------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        String msg = PLAIN.serialize(e.message());
        int maxLen = cfg().getInt("protection.chat.max-length", 256);
        int max = cfg().getInt("protection.chat.max-per-window", 6);
        long win = cfg().getLong("protection.chat.window-seconds", 5) * 1000L;
        if (msg.length() > maxLen || rate.exceeded("chat:" + p.getUniqueId(), max, win)) {
            e.setCancelled(true);
            hit("chat", p.getName());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        int maxLen = cfg().getInt("protection.command.max-length", 256);
        int max = cfg().getInt("protection.command.max-per-window", 10);
        long win = cfg().getLong("protection.command.window-seconds", 3) * 1000L;
        if (e.getMessage().length() > maxLen || rate.exceeded("cmd:" + p.getUniqueId(), max, win)) {
            e.setCancelled(true);
            hit("command", p.getName());
        }
    }

    // ---------- Books / signs / anvil ----------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBook(PlayerEditBookEvent e) {
        if (bypass(e.getPlayer())) return;
        BookMeta meta = e.getNewBookMeta();
        int maxPages = cfg().getInt("protection.book.max-pages", 50);
        int maxChars = cfg().getInt("protection.book.max-chars-per-page", 800);
        boolean bad = meta.getPageCount() > maxPages;
        if (!bad) {
            for (Component page : meta.pages()) {
                if (PLAIN.serialize(page).length() > maxChars) { bad = true; break; }
            }
        }
        if (bad) {
            e.setCancelled(true);
            hit("book", e.getPlayer().getName());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSign(SignChangeEvent e) {
        if (bypass(e.getPlayer())) return;
        int max = cfg().getInt("protection.sign.max-line-length", 45);
        for (Component line : e.lines()) {
            if (PLAIN.serialize(line).length() > max) {
                e.setCancelled(true);
                hit("sign", e.getPlayer().getName());
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAnvil(PrepareAnvilEvent e) {
        String name = e.getView().getRenameText();
        if (name != null && name.length() > cfg().getInt("protection.anvil.max-name-length", 50)) {
            e.setResult(null);
            blocked.incrementAndGet();
        }
    }

    // ---------- Inventory / drops ----------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || bypass(p)) return;
        int max = cfg().getInt("protection.inventory.max-clicks-per-second", 40);
        if (rate.exceeded("click:" + p.getUniqueId(), max, 1000)) {
            e.setCancelled(true);
            hit("inventory-spam", p.getName());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCreative(InventoryCreativeEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || bypass(p)) return;
        if (cfg().getBoolean("protection.inventory.block-creative-for-non-creative", true)
                && p.getGameMode() != GameMode.CREATIVE) {
            e.setCancelled(true);
            hit("fake-creative-packet", p.getName());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (bypass(p)) return;
        int max = cfg().getInt("protection.drop.max-per-second", 15);
        if (rate.exceeded("drop:" + p.getUniqueId(), max, 1000)) {
            e.setCancelled(true);
            hit("drop-spam", p.getName());
        }
    }

    // ---------- Invalid movement ----------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        double x = to.getX(), y = to.getY(), z = to.getZ();
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)
                || Math.abs(x) > 3.0E7 || Math.abs(z) > 3.0E7 || Math.abs(y) > 1.0E6) {
            e.setCancelled(true);
            hit("invalid-move", e.getPlayer().getName());
        }
    }

    // ---------- World lag: redstone / entities / TNT / fireworks ----------
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onRedstone(BlockRedstoneEvent e) {
        int max = cfg().getInt("protection.redstone.max-changes-per-chunk-per-second", 600);
        if (rate.exceeded("rs:" + chunkKey(e.getBlock().getLocation()), max, 1000)) {
            e.setNewCurrent(e.getOldCurrent());
            blocked.incrementAndGet();
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSpawn(EntitySpawnEvent e) {
        Entity ent = e.getEntity();

        if (ent instanceof Firework fw) {
            FireworkMeta m = fw.getFireworkMeta();
            if (m.getEffectsSize() > cfg().getInt("protection.firework.max-effects", 8)
                    || m.getPower() > cfg().getInt("protection.firework.max-flight", 3)) {
                e.setCancelled(true);
                hit("firework", "world");
                return;
            }
        }

        int cap = cfg().getInt("protection.entities.max-per-chunk", 150);
        Entity[] inChunk = e.getLocation().getChunk().getEntities();
        if (inChunk.length >= cap) {
            int nonPlayers = 0;
            for (Entity o : inChunk) if (!(o instanceof Player)) nonPlayers++;
            if (nonPlayers >= cap) {
                e.setCancelled(true);
                blocked.incrementAndGet();
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onExplosionPrime(ExplosionPrimeEvent e) {
        int max = cfg().getInt("protection.explosions.max-tnt-per-chunk-per-second", 40);
        if (rate.exceeded("tnt:" + chunkKey(e.getEntity().getLocation()), max, 1000)) {
            e.setCancelled(true);
            e.getEntity().remove();
            blocked.incrementAndGet();
        }
    }
}
