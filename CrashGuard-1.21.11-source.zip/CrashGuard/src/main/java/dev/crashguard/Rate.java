package dev.crashguard;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Simple fixed-window rate limiter. */
final class Rate {
    private final Map<String, long[]> map = new ConcurrentHashMap<>();

    boolean exceeded(String key, int max, long windowMs) {
        long now = System.currentTimeMillis();
        long[] a = map.computeIfAbsent(key, k -> new long[]{now, 0});
        synchronized (a) {
            if (now - a[0] > windowMs) {
                a[0] = now;
                a[1] = 0;
            }
            return ++a[1] > max;
        }
    }

    void cleanup() {
        long now = System.currentTimeMillis();
        map.entrySet().removeIf(e -> now - e.getValue()[0] > 60_000);
    }
}
