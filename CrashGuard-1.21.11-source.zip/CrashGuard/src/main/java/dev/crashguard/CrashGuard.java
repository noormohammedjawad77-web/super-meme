package dev.crashguard;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class CrashGuard extends JavaPlugin {

    private DupeDbSync sync;
    private Protections protections;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        protections = new Protections(this);
        Bukkit.getPluginManager().registerEvents(protections, this);
        sync = new DupeDbSync(this);

        // تنظيف الـ rate limiter كل دقيقة
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, protections.rate()::cleanup, 1200L, 1200L);

        scheduleSync();
        getLogger().info("CrashGuard enabled.");
    }

    private void scheduleSync() {
        if (!getConfig().getBoolean("dupedb.enabled", true)) return;
        long ticks = Math.max(10, getConfig().getLong("dupedb.sync-interval-minutes", 60)) * 60L * 20L;
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> sync.run(false), 100L, ticks);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("crashguard.admin")) {
            s.sendMessage("§cNo permission.");
            return true;
        }
        String sub = a.length == 0 ? "status" : a[0].toLowerCase();
        switch (sub) {
            case "sync" -> {
                s.sendMessage("§eSyncing with DupeDB...");
                Bukkit.getScheduler().runTaskAsynchronously(this, () -> sync.run(true));
            }
            case "list" -> {
                List<DupeDbSync.Entry> m = sync.matches();
                if (m.isEmpty()) {
                    s.sendMessage("§aNo matching active crash exploits found.");
                } else {
                    s.sendMessage("§6Active crash exploits matching your server (" + m.size() + "):");
                    for (DupeDbSync.Entry e : m) {
                        s.sendMessage("§7- §f" + e.name() + " §8[" + e.id() + "] §e" + e.plugin());
                    }
                }
            }
            case "test" -> Bukkit.getScheduler().runTaskAsynchronously(this, () ->
                    s.sendMessage(sync.sendTest() ? "§aTest embed sent." : "§cFailed (check dupedb.webhook-url)."));
            case "reload" -> {
                reloadConfig();
                s.sendMessage("§aConfig reloaded.");
            }
            default -> {
                s.sendMessage("§6CrashGuard §7- " + sync.status());
                s.sendMessage("§7Blocked so far: §f" + protections.blocked());
                s.sendMessage("§7/cg sync | list | test | reload");
            }
        }
        return true;
    }
}
